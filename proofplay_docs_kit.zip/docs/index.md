# ProofPlay Compliance Engine
*Verifiable decisions for regulated workflows (insurance, healthcare, fintech).*

**Live demo:** https://proofplay-compliance-demo.vercel.app/  
**API (GPM-SC backend):** https://gpmsc-api.onrender.com  
**Contact:** tickets8383@icloud.com

---

## In 60 seconds
1) Open the demo UI and click an example “rule chip” (e.g., **Coverage → Approve**)  
2) Click **Verify Rule Consistency** → you get a result plus an **audit_id**  
3) Click that **audit_id** in the live stream (or paste it) → **Verify Audit Integrity** → ✅ PASS  
4) Export an evidence packet (PDF/JSON bundle) for auditors / disputes (pilot deliverable)

![Verify flow](assets/verify-flow.gif)

---

## What it does
### 1) Verify rules before deployment
- Check rule sets for contradictions, edge cases, and circular dependencies (Z3 / SMT).
- Accepts strict formal logic (∧ ∨ ¬ →) and deterministic “Business Mode” preprocessing.

### 2) Make every decision *provable*
- Every verification/decision can produce:
  - a durable **audit record ID**
  - **hash‑chained** tamper evidence (append‑only)
  - **RFC 3161 TSA** timestamp evidence (third‑party anchored)

### 3) Re‑verify later (“don’t trust us—verify”)
- Anyone can re-check integrity using `/audit/{id}/integrity` (and see exactly what was logged).

![Architecture](assets/architecture.png)

---

## How it works (high level)

```mermaid
flowchart LR
  A[Rule / Decision Request] --> B[Verify (Z3 or deterministic Business Mode)]
  B --> C[Response + audit_id]
  C --> D[Audit record (hash chained)]
  D --> E[RFC 3161 TSA timestamp]
  C --> F[Integrity verify endpoint]
  F --> G[PASS / FAIL]
  C --> H[Evidence export (PDF/JSON)]
```

---

## Pilot package (fixed scope, fixed price)
**4‑week pilot · up to 30 rules · deploy + audit evidence export**

**You get**
- Rule intake + normalization (your policy docs → deterministic rule set)
- Verification checks (contradictions / edge cases) + a short “findings” report
- Deployed verification + audit trail endpoints (staging or your environment)
- Evidence export (PDF/JSON bundle) for a set of sample decisions
- Success metrics + handoff docs

**Success metrics (example)**
- Contradictions/edge cases surfaced pre‑prod
- End‑to‑end: verify → audit_id → integrity PASS
- Evidence packet generated for sampled decisions
- Latency + reliability targets agreed up front

---

## Screenshots
![Audit integrity verified](assets/audit-integrity.png)

![Evidence export](assets/pdf-affidavit.png)
