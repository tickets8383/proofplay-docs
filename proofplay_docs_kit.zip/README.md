# ProofPlay Documentation

**Forwardable 1‑pager:** `/docs` (enable GitHub Pages → share a clean link)

- Live compliance demo UI: https://proofplay-compliance-demo.vercel.app/
- API (GPM-SC backend): https://gpmsc-api.onrender.com
- Contact: tickets8383@icloud.com

This repo contains documentation for ProofPlay services and APIs.

## Start here
If you only read one thing: open the **Compliance Engine 1‑pager** in `docs/index.md` (it includes screenshots + a 60‑second walkthrough).

## Existing docs
- `API.md` — ProofPlay Bingo API
- `GPM-SC_API.md` — GPM‑SC Reasoning/Verification API
- `RESELLING.md` — integration/reselling notes
