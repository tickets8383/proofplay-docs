# 5‑minute demo script (repeatable)

## Goal (10 seconds)
“ProofPlay makes decisions verifiable: we can *verify rules before deployment*, generate an **audit_id** for each decision, prove the record wasn’t tampered with later, and (in the pilot) export an evidence packet auditors can reuse.”

---

## Part A — Rule verification + graph (2 minutes)

1) **Open the demo**  
   https://proofplay-compliance-demo.vercel.app/

2) **Pick an example chip**  
   Click an example like **Coverage → Approve**.

3) **Verify**  
   Click **Verify Rule Consistency**.

4) **Show the result**
   - Point to the Mermaid **logic graph**.
   - Switch to **JSON Result** and call out:
     - `is_logically_valid`
     - `audit_id`
     - (Business Mode) `normalized_statement` + `transforms_applied` (deterministic preprocessing)

**One line:** “We’re not asking you to trust a model—this is deterministic verification + a tamper‑evident record.”

---

## Part B — Integrity verification (1.5 minutes)

5) **Auto‑fill via audit stream**
   In **Live Audit Stream**, click any recent `audit_id` (or paste one from Part A).

6) **Verify integrity**
   Click **Verify Audit Integrity** → show ✅ PASS.

**One line:** “If anyone changes history, the hash chain breaks and this fails.”

---

## Part C — Evidence export (1 minute)

7) **Export evidence (pilot deliverable)**
   Show the **Download Affidavit / Attestation Report** button and download the packet.

Call out what’s inside:
- audit_id + decision snapshot
- RFC 3161 timestamp evidence
- integrity summary
- the rule text + a capture of the logic graph

---

## Close (20 seconds)
“Pilot is fixed scope: 4 weeks, up to 30 rules, deploy + evidence export, success metrics. If the demo matches what you’d want, a one‑sentence gut check is plenty.”
