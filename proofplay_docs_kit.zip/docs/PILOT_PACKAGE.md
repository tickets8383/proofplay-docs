# Pilot package (fixed scope)

**4‑week pilot · up to 30 rules · deploy + audit evidence export · success metrics**

## Week-by-week
**Week 1 — Intake + mapping**
- Collect 10–30 candidate rules (policy docs, SOPs, decision tables)
- Define “success metrics” + target workflow
- Choose deployment target (staging / your environment / hosted)

**Week 2 — Rule normalization + verification**
- Translate rules into formal logic or deterministic business mode equivalents
- Run contradiction / edge-case checks
- Deliver a short findings report + recommended remediations

**Week 3 — Integration + audit trail**
- Integrate calls into your rule engine / decision service (REST)
- Ensure every decision returns an `audit_id`
- Enable `/audit/recent` + `/audit/{id}/integrity`

**Week 4 — Evidence export + handoff**
- Evidence export (PDF + JSON bundle) for sampled decisions
- Run a “mock audit” walkthrough
- Handoff docs + next-step estimate for production rollout

## Deliverables
- Deployed pilot instance (or integration into yours)
- 10–30 normalized rules + verification results
- Audit trail + integrity verification working end-to-end
- Evidence packet template (PDF/JSON)
- Success metrics report

## Pricing (simple)
**Fixed: $50k USD** for the pilot scope above.  
Optional add-ons: extra rule batches, on-prem hardening, SLA.
